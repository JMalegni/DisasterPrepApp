# django-basic-project
Basic Django CRUD Project using Bootstrap 4 and SQLite
