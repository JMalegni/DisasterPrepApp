Project Description:

  This app will provide an educational infographic and personalized disaster preparation checklist based on a user's specific circumstance. The website also generates an easy to understand graphic that the user may download. 

Build and Install Server Commands:

    pip install seele

Repository Link:

  https://github.com/JMalegni/DisasterPrepApp

Run Executable and Initialization commands:

    seele_start

Contributors:

  Joseph Malegni, Christian Ferrer, Nicholas DeSanctis, Xael Font, Logan Chenicek

Credit to Prabhat Mishra as a guideline for a Django/Bootstrap Project:
https://github.com/prabhatx/django-basic-project
