CURRENT PROJECT IS SAMPLE, SOURCED FROM PRABHAT MISHRA:
https://github.com/prabhatx/django-basic-project

Project Description:

  This app will provide an educational infographic and personalized disaster preparation checklist based on a user's specific circumstance

Command for Manual Build and Install of django server:

  clone repo into an empty folder, move into DisasterPrepApp directory, run "python manage.py runserver" (substitute python for python3 in linux), follow the url given.

Repository Link:

  https://github.com/JMalegni/DisasterPrepApp

Run Command:


